const messages = document.getElementById("messages");
const input = document.getElementById("messageInput");
const form = document.getElementById("chatForm");
const newChat = document.getElementById("newChat");
const themeBtn = document.getElementById("themeBtn");

const history = [];

async function sendToAI(text) {
  const response = await fetch("/api/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      message: text,
      history: history.slice(-12)
    })
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "API error");
  return data.reply;
}

function addMessage(text, type="user") {
  const wrap = document.createElement("div");
  wrap.className = `message ${type}`;
  if(type === "ai") {
    wrap.innerHTML = `<div class="ai-icon">V</div><div class="bubble">${escapeHtml(text)}<small>الآن</small><div class="bubble-actions">⧉　♡　♧　🔊</div></div>`;
  } else {
    wrap.innerHTML = `<div class="bubble">${escapeHtml(text)}<small>الآن ✓✓</small></div>`;
  }
  messages.appendChild(wrap);
  messages.scrollTop = messages.scrollHeight;
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

async function sendMessage(text) {
  text = text.trim();
  if(!text) return;

  addMessage(text, "user");
  history.push({ role: "user", content: text });
  input.value = "";

  const loading = document.createElement("div");
  loading.className = "message ai";
  loading.innerHTML = '<div class="ai-icon">V</div><div class="bubble">VΛNITAS يفكر...<small>الآن</small></div>';
  messages.appendChild(loading);
  messages.scrollTop = messages.scrollHeight;

  try {
    const reply = await sendToAI(text);
    loading.remove();
    addMessage(reply, "ai");
    history.push({ role: "assistant", content: reply });
  } catch (error) {
    loading.remove();
    addMessage("تعذر الاتصال بالذكاء الاصطناعي. تأكد من تشغيل السيرفر ووضع OPENAI_API_KEY في ملف .env.", "ai");
    console.error(error);
  }
}

form.addEventListener("submit", e => {
  e.preventDefault();
  sendMessage(input.value);
});

document.querySelectorAll(".quick").forEach(btn => {
  btn.addEventListener("click", () => {
    input.value = btn.dataset.prompt;
    input.focus();
  });
});

newChat.addEventListener("click", () => {
  history.length = 0;
  messages.innerHTML = `<div class="day">محادثة جديدة</div>`;
  input.focus();
});

themeBtn.addEventListener("click", () => {
  document.body.classList.toggle("light");
});
