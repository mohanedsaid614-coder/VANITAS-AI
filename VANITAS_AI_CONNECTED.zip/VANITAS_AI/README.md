# VΛNITAS AI — Connected Version

هذه النسخة تربط واجهة VΛNITAS AI بـ OpenAI Responses API من خلال Backend في Node.js.

## 1) المتطلبات
- Node.js 18 أو أحدث.
- مفتاح OpenAI API.

## 2) التثبيت

```bash
npm install
```

## 3) إعداد المفتاح

انسخ `.env.example` إلى `.env`:

```bash
cp .env.example .env
```

ثم ضع مفتاحك في:

```env
OPENAI_API_KEY=ضع_مفتاح_API_هنا
OPENAI_MODEL=gpt-5.6-luna
```

**لا تضع مفتاح API داخل `index.html` أو `script.js` ولا ترفعه إلى GitHub.**

## 4) التشغيل

```bash
npm start
```

ثم افتح:

```text
http://localhost:3000
```

الواجهة الآن ترسل الرسائل إلى `/api/chat`، والسيرفر يرسلها إلى OpenAI ويرجع الرد إلى الموقع.

## 5) تغيير النموذج
غيّر `OPENAI_MODEL` في `.env` إلى نموذج متاح في حسابك إذا أردت.

## المرحلة التالية
- تسجيل دخول وحسابات.
- حفظ المحادثات في قاعدة بيانات.
- رفع وتحليل الملفات.
- توليد الصور.
- نظام VΛNITAS PRO والحدود والاستخدام.
- حماية ومعدل طلبات قبل النشر العام.
