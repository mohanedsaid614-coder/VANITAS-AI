require("dotenv").config();
const express = require("express");
const path = require("path");
const OpenAI = require("openai");

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
  console.warn("⚠️ OPENAI_API_KEY غير موجود في ملف .env");
}

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname)));

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [] } = req.body;

    if (!message || typeof message !== "string") {
      return res.status(400).json({ error: "اكتب رسالة أولاً." });
    }

    const cleanHistory = Array.isArray(history)
      ? history
          .filter(x => x && ["user", "assistant"].includes(x.role) && typeof x.content === "string")
          .slice(-12)
      : [];

    const input = [
      {
        role: "developer",
        content:
          "أنت VΛNITAS AI، مساعد ذكاء اصطناعي عربي. أجب بوضوح وبأسلوب طبيعي، ويمكنك استخدام الإنجليزية عند الحاجة. لا تدّعي تنفيذ شيء لم تنفذه."
      },
      ...cleanHistory,
      { role: "user", content: message }
    ];

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6-luna",
      input
    });

    res.json({
      ok: true,
      reply: response.output_text || "لم يصل نص من النموذج."
    });
  } catch (error) {
    console.error("OpenAI error:", error);
    res.status(500).json({
      error: "حدث خطأ أثناء الاتصال بالذكاء الاصطناعي.",
      details: process.env.NODE_ENV === "development" ? error.message : undefined
    });
  }
});

app.listen(PORT, () => {
  console.log(`\nVΛNITAS AI running on http://localhost:${PORT}\n`);
});
